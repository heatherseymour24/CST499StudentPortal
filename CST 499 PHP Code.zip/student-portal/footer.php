<?php
error_reporting(E_ALL ^ E_NOTICE);
?>
<div class="navbar row-fluid">
    <div class="navbar-inner">
        <div class="container text-center">
            <p>Copyright © 2025</p>
        </div>
    </div>
</div>
</body>
</html>

